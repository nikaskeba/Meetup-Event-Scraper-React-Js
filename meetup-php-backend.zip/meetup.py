import requests
from bs4 import BeautifulSoup
import json
import pandas as pd

def scrape_website(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        group_title = soup.find('h1').get_text(strip=True)
        link_tag = soup.find('a', id="group-name-link")
        group_link = link_tag['href'] if link_tag else None
        items = []
        li_tags = soup.find_all('li')
        for li in li_tags:
            time_tag = li.find('time', class_="text-[#00829B] text-sm font-medium uppercase")
            if not time_tag or not time_tag.get_text(strip=True):
                continue # Skip if time is missing or blank
            a_tag = li.find('a')
            event_link = a_tag['href'] if a_tag and a_tag.has_attr('href') else 'No link found'
            all_tags = li.find_all(['time', 'p', 'span'])
            title, location, *description_parts = [tag.get_text(strip=True) for tag in all_tags[1:]]  # Skip the first time tag
            description = ' '.join(part for part in description_parts if 'jpeg' not in part and 'attendees' not in part)
            items.append({
                "time": time_tag.get_text(strip=True),
                "title": title,
                "location": location,
                "description": description,
                "event_link": event_link
            })
        return {
            "group_title": group_title,
            "group_link": group_link,
            "items": items
        }
    except requests.HTTPError as e:
        return f"Failed to retrieve the website, status code: {e.response.status_code}"
    except Exception as e:
        return str(e)

# Read URLs from the meetup.csv file in the same directory
urls = pd.read_csv('meetup.csv', header=None).iloc[:,0].tolist()

# Process each URL and aggregate data
all_data = []
for url in urls:
    # Append '/events/' to the URL if it's not already there
    if not url.endswith('events/'):
        url += 'events/'
    print(f"Processing: {url}")
    data = scrape_website(url)
    # Check if items list is empty; if not, append to all_data
    if data.get("items", []):  # This will check if items list is non-empty
        all_data.append(data)

# Save the aggregated data into a JSON file with indentation
with open('meetup.json', 'w') as json_file:
    json.dump(all_data, json_file, indent=4)

print("Data saved to meetup.json")
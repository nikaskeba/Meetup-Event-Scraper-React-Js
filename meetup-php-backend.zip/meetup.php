<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: POST, GET, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, X-Requested-With");
header('Content-Type: application/json');
// Check if timestamp file exists
$timestampFile = 'timestamp.txt';
if (file_exists($timestampFile)) {
    // Read the contents of the timestamp file
    $timestamp = trim(file_get_contents($timestampFile));

    // Check if the timestamp matches the current date
    $currentDate = date('Y-m-d');
    if ($timestamp === $currentDate) {
        echo "Already updated";
    } else {
        runPythonScript();
    }
} else {
    runPythonScript();
}

// Function to run the Python script and create/overwrite meetup.json
function runPythonScript()
{
    $command = 'python3 meetup.py';
    $output = shell_exec($command);
    echo $output;

    // Update the timestamp file with the current date
    $currentDate = date('Y-m-d');
    file_put_contents('timestamp.txt', $currentDate);
}
?>